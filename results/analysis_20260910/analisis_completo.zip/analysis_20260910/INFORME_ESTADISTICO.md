# Análisis estadístico de incertidumbre y branching en generación de código

Consulta de fuentes: 10 de septiembre de 2026. Autor del experimento: Matias Koroch. Análisis retrospectivo reproducible; no se volvió a ejecutar el modelo ni el código generado.

## Resultado principal

La intervención top-2 recupera soluciones en esta cohorte: cada selector informado recupera 10/20 problemas fallidos con cinco ramas, frente a 6/20 del control aleatorio. **El selector semántico no demostró superioridad sobre entropía ni margen.** La ventaja observada sobre aleatorio es de 20 puntos porcentuales, pero ninguna comparación pareada supera el umbral de 0,05 con la prueba exacta, incluso antes de corregir comparaciones múltiples. Hay evidencia global limítrofe de diferencias entre los cuatro selectores (p exacta condicional = 0,04785), que no identifica un ganador.

El desfase posicional tiene presencia cuantificable: 309/1.649 ventanas (18,7%) muestran alta discrepancia por índice y baja distancia de edición según el criterio exploratorio detallado abajo. Eso cuestiona la interpretación semántica de la métrica, aunque no invalida los PASS registrados.

## Fuentes y alcance

- [Validación branching adaptativo — 20 problemas](https://docs.google.com/spreadsheets/d/1M5npFrFTIBJVB8QdpX9CXVhdMSO4l4Apd48I37OHDeE/edit). Se leyeron sus seis pestañas: Metodología, Resumen, Presupuesto, Problemas, Ramas y Lookaheads. Última modificación informada: 26/08/2026. Pestañas de datos: Presupuesto A1:F401, Problemas A1:I21, Ramas A1:O256 y Lookaheads A1:M1650.

- [Hummaneval_mbpp](https://docs.google.com/spreadsheets/d/1AVyjP-cT0JYmReT7mDqQ0LF5Om7aZi-yst8bq3YK-qU/edit). Datos de las pestañas humaneval y mbpp, analizados por separado. Última modificación informada: 23/07/2026. Se usaron los registros, no los promedios ya preparados en las otras pestañas.

- [Bitácora del proyecto](https://docs.google.com/document/d/1gHe8uYzdAu0LAVPVRDUQGtX15cSZa5MvIbyfsq2fxQU/edit): contexto de desarrollo y advertencia previa de desfase. Última modificación informada: 03/09/2026. El piloto HumanEval/26 y los experimentos RAG anteriores no se mezclaron con la validación.

- Archivos originales locales en `sheet_build_data/`, que el constructor de la planilla identifica como procedentes de `frozen_selector_validation_checkpoint (1).zip`. Se cotejaron claves, etiquetas y valores numéricos con Drive antes de usarlos para las trayectorias, latencias y controles de integridad ausentes en la planilla.

Se incluyen ambos experimentos por separado, con foco principal en branching. Las tasas anteriores de éxito y la tasa de recuperación de fallos son estimandos distintos; no se suman sus denominadores.

## 1. Diseño, población y calidad de datos

El protocolo congelado usa Qwen/Qwen2.5-Coder-7B-Instruct, generación greedy, una sustitución por el top-2 guardado y continuación greedy. Se seleccionan cinco posiciones por selector; el selector semántico combina tres percentiles intraproblema con pesos 1/3. El horizonte máximo es de 12 tokens, incluido el forzado, y el límite de generación completa es de 256 tokens. HumanEval/26 queda excluido por haber intervenido en el diseño.

| Unidad | Cantidad | Uso |
| --- | --- | --- |
| Problemas fallidos elegibles | 20 | Unidad principal de inferencia |
| Selecciones nominales | 400 | 20 × 4 selectores × 5; con solapamientos |
| Ramas completas únicas | 255 | 29 PASS, 226 FAIL |
| Lookaheads | 1649 | Ventanas; no observaciones independientes |
| Posiciones sin evaluación completa | 1394 | 84,5%; resultado desconocido, nunca imputado como FAIL |


No hay duplicados de (task_id, position) en las 255 ramas ni en los 1.649 lookaheads. Las 400 selecciones tienen cinco posiciones distintas por problema y selector; sus etiquetas y acumulados coinciden con las ramas completas. Las claves y métricas numéricas de los originales coinciden con Drive. Una diferencia de texto en HumanEval/77 posición 7 corresponde únicamente a CRLF frente a LF.

**Defecto de exportación:** los 1.649 `semantic_score` de Lookaheads están vacíos. Se reconstruyeron a partir de los percentiles con empates (midranks) de persistencia, divergencia ponderada y anchor_score. En las 255 ramas que sí guardan score, el error máximo es 2,22 × 10⁻¹⁶. La ausencia no se interpretó como cero. La hoja original quedó intacta.

El archivo de baselines contiene 141 tareas: 120 PASS y 21 FAIL. HumanEval/120 no ingresa a la cohorte de 20 por no cumplir la cantidad de posiciones elegibles del protocolo. Por tanto, el 50% es recuperación condicional en esta cohorte; no es pass@1 del benchmark ni un aumento de 50 puntos en el rendimiento general.

Los intervalos y pruebas tratan los problemas como unidades intercambiables para una inferencia de trabajo. HumanEval es un benchmark fijo, las tareas pueden compartir estructura y la cohorte fue seleccionada por fallo; los intervalos no garantizan cobertura sobre todo el código del mundo real.

## 2. Recuperación y precisión de rama

| Selector | Recuperados | Tasa | IC 95% Wilson | Ramas PASS / 100 | IC bootstrap por problema |
| --- | --- | --- | --- | --- | --- |
| Semántico | 10/20 | 50.0% | 29.9%–70.1% | 15 | 7.0%–24.0% |
| Entropía | 10/20 | 50.0% | 29.9%–70.1% | 21 | 11.0%–32.0% |
| Margen | 10/20 | 50.0% | 29.9%–70.1% | 21 | 11.0%–31.0% |
| Aleatorio | 6/20 | 30.0% | 14.5%–51.9% | 7 | 2.0%–12.0% |


La última columna corresponde a la precisión de rama, no a la tasa de problemas recuperados. Se remuestrean 20 problemas completos, conservando las cinco ramas de cada selector. Tratar las 100 ramas como ensayos independientes produciría incertidumbre incorrecta. Un problema con varias ramas PASS aporta una sola recuperación.

![Recuperación y presupuesto](/Users/matiask/Documents/programacion/LIS/ghost_prompt/analysis_20260910/01_recuperacion.png)

## 3. Comparaciones pareadas y multiplicidad

Se usa McNemar exacta bilateral sobre los problemas discordantes. La familia principal contiene las seis comparaciones posibles; se aplica Holm. Se muestran intervalos conservadores para la diferencia de tasas, construidos restando límites Clopper–Pearson de las dos celdas discordantes, cada uno al 97,5% (Bonferroni, cobertura conjunta al menos 95%). Son amplios deliberadamente.

| Comparación A − B | Solo A / solo B | Diferencia | IC conservador 95% | p exacta | p Holm (6) |
| --- | --- | --- | --- | --- | --- |
| Semántico − Entropía | 1 / 1 | +0 pp | [-27.9, +27.9] pp | 1.00000 | 1.000 |
| Semántico − Margen | 1 / 1 | +0 pp | [-27.9, +27.9] pp | 1.00000 | 1.000 |
| Semántico − Aleatorio | 5 / 1 | +20 pp | [-20.7, +52.2] pp | 0.21875 | 0.875 |
| Entropía − Margen | 0 / 0 | +0 pp | [-19.7, +19.7] pp | 1.00000 | 1.000 |
| Entropía − Aleatorio | 4 / 0 | +20 pp | [-15.0, +46.9] pp | 0.12500 | 0.750 |
| Margen − Aleatorio | 4 / 0 | +20 pp | [-15.0, +46.9] pp | 0.12500 | 0.750 |


Semántico frente a aleatorio: gana en cinco problemas, pierde en uno, ambos recuperan cinco y ninguno recupera nueve. El efecto observado de +20 pp es interesante, pero p=0,21875 no permite afirmar superioridad. Semántico frente a entropía: cada uno tiene una recuperación exclusiva; el empate no demuestra equivalencia.

La prueba global de Cochran produce Q=8. La aproximación χ² con tres grados de libertad da p=0,04601. Enumerar exactamente las 4.096 asignaciones posibles de etiquetas de selector dentro de los seis problemas no constantes, manteniendo sus totales, da p=0,0478516. Esta prueba presupone intercambiabilidad de las etiquetas bajo la hipótesis nula; es evidencia global débil, sin atribución a una comparación específica. Las pruebas pareadas exactas son discretas y, con tan pocos discordantes, tienen poca resolución.

Los JSON también conservan intervalos bootstrap percentiles como sensibilidad. Con celdas discordantes vacías pueden dar intervalos engañosamente estrechos (entropía frente a margen llega a [0,0]); por eso no se usan como prueba de equivalencia ni para contradecir las pruebas exactas.

## 4. Presupuesto de búsqueda y control aleatorio

| k | Semántico | Entropía | Margen | Aleatorio guardado¹ | Aleatorio orden promediado² |
| --- | --- | --- | --- | --- | --- |
| 1 | 5 | 8 | 6 | 4 | 1.4 |
| 2 | 7 | 10 | 8 | 5 | 2.7 |
| 3 | 7 | 10 | 10 | 6 | 3.9 |
| 4 | 8 | 10 | 10 | 6 | 5.0 |
| 5 | 10 | 10 | 10 | 6 | 6.0 |


Valores: problemas recuperados de 20. ¹ Las cinco posiciones aleatorias se guardaron ordenadas por posición, no en orden aleatorio. Los primeros k<5 favorecen posiciones tempranas y no constituyen un control uniforme de k posiciones. ² Esperanza al promediar todos los órdenes de las cinco posiciones guardadas: para m ramas PASS, probabilidad de recuperación = 1 − C(5−m,k)/C(5,k). Es una reconstrucción condicional, no una nueva corrida ni un conteo observado. En k=5 ambas coinciden.

Entropía alcanza sus diez recuperaciones con dos ramas; margen con tres; semántico necesita cinco. Esta es una comparación descriptiva bajo el protocolo y cohorte observados. Elegir k=2 después de mirar los datos y presentarlo como resultado preespecificado sería incorrecto.

## 5. Redundancia y complementariedad

Entropía y margen comparten 93/100 posiciones seleccionadas y recuperan exactamente los mismos diez problemas. En los 1.649 lookaheads, Spearman entre entropía y margen probabilístico es −0,99766; la mediana de las 20 correlaciones intraproblema es −0,99585. Es una relación de estas distribuciones, no una identidad matemática universal entre las métricas.

Semántico y entropía comparten 34/100 posiciones. Semántico recupera HumanEval/121, que entropía no recupera; entropía recupera HumanEval/95, que semántico no recupera. Su unión recupera 11/20, pero consume 166 ramas únicas (8,3 por problema en promedio), frente a 100 por selector. No es una mejora a presupuesto constante.

Como exploración posterior se construyó una política de cinco ramas: dos primeras por entropía y completar con semántico sin repetir posiciones. Recupera 11/20 usando etiquetas ya conocidas. **No es validación independiente**: la política se propuso después de examinar esta cohorte y debe congelarse antes de probarla en datos nuevos.

## 6. ¿Qué señales discriminan ramas útiles?

Se compara una rama PASS con una FAIL del mismo problema, promediando AUC por problema para evitar que dominen las tareas con más posiciones. Solo once problemas tienen ambos resultados y aportan a este análisis.

| Señal (dirección) | AUC intraproblema media | IC bootstrap 95% |
| --- | --- | --- |
| entropy mayor | 0.774 | [0.597, 0.896] |
| Margen menor | 0.759 | [0.583, 0.881] |
| persistence_after_forced mayor | 0.643 | [0.571, 0.711] |
| weighted_semantic_divergence mayor | 0.621 | [0.518, 0.730] |
| anchor_score mayor | 0.689 | [0.569, 0.798] |
| normalized_edit_distance mayor | 0.693 | [0.609, 0.773] |
| score_recomputed mayor | 0.670 | [0.575, 0.770] |


AUC=0,5 indica ausencia de orden discriminante y AUC=1 separación perfecta bajo esta comparación. Estos valores describen únicamente las 255 posiciones elegidas por la unión de los selectores. Hay sesgo de selección y no se conocen las etiquetas de las otras 1.394 posiciones: no estiman la capacidad predictiva en todas las posiciones, ni el recall respecto de un oracle exhaustivo. Tampoco permiten declarar diferencias significativas entre las AUC sin una comparación pareada específica.

## 7. Desfase, aproximación semántica y controles de integridad

Se recalcularon independientemente las distancias de Levenshtein, la discrepancia posicional y la persistencia a partir de los IDs de tokens originales de las 1.649 ventanas. Los máximos errores frente a los valores guardados fueron cero.

El criterio diagnóstico exploratorio `aligned_mismatch ≥ 0,8` y `normalized_edit_distance ≤ 0,3` marca 309 ventanas (18,7%). Con cortes cercanos (≥0,75/≤0,25 y ≥0,9/≤0,3) marca 310 y 308; ampliando edición a 0,4 marca 394 (23,9%). El criterio no fue ajustado a las etiquetas PASS/FAIL. **No identifica automáticamente equivalencia semántica ni mide el porcentaje de errores de la métrica.**

| Selector | Ventanas marcadas / 100 | PASS entre las marcadas |
| --- | --- | --- |
| Semántico | 4 | 0 |
| Entropía | 9 | 2 |
| Margen | 11 | 2 |
| Aleatorio | 16 | 0 |


Ejemplo real: HumanEval/140, posición 4. La ventana original empieza con `):` seguido de salto de línea y termina en `.replace`; la alternativa agrega un espacio/salto de línea y termina antes, en `)).`. La discrepancia posicional y persistencia son 1,00, mientras que la distancia de edición es 0,25. El corrimiento y el corte de ventana pueden explicar buena parte de la discrepancia. No se puede concluir solo con esos fragmentos que los programas completos sean equivalentes.

El score combina persistencia, divergencia léxica ponderada y anchors; Levenshtein se calcula pero no entra al score. La clasificación se hace sobre fragmentos del tokenizador del LLM, que no son necesariamente tokens completos de Python. Además, la función clasifica cualquier fragmento con salto de línea como whitespace, aunque incluya código; resta importancia a identificadores y espacios, pese a que renombrar o cambiar indentación puede alterar el programa. Los anchors ignoran orden y multiplicidad. Estas decisiones limitan el uso de “semántico” como interpretación literal.

88 ventanas terminaron antes de los 12 tokens (5,3%); la comparación posicional puede penalizar toda la cola faltante. Solo tres ventanas cortas están en el top-5 semántico y ninguna pasa. Dos baselines (HumanEval/32 y /81) y 21 ramas completas alcanzan el límite de 256 tokens: sus fallos pueden estar condicionados por truncamiento.

En tres posiciones cambia el par ordenado top-1/top-2 al recalcular: HumanEval/141 posición 32 (el token forzado queda rank 1), HumanEval/38 posición 87 (rank 3) y HumanEval/95 posición 43 (rank 2, cambia el otro miembro del par). El control guardado usa conjuntos y oculta el intercambio de orden del primer caso. Solo la posición con rank 1 está entre las ramas evaluadas completas y falla. Restringir las recuperaciones a alternativas consistentes de rango 2 conserva los conteos 10/10/10/6. Esto no sustituye repetir la generación con un protocolo numéricamente consistente.

![Desfase y costos](/Users/matiask/Documents/programacion/LIS/ghost_prompt/analysis_20260910/02_desfase_costos.png)

## 8. Costos de cómputo

| Selector | Ramas completas (min) | Lookaheads (min) | Suma reconstruida (min) |
| --- | --- | --- | --- |
| Semántico | 5.59 | 29.40 | 34.98 |
| Entropía | 7.27 | 0.00 | 7.27 |
| Margen | 7.02 | 0.00 | 7.02 |
| Aleatorio | 6.07 | 0.00 | 6.07 |


El semántico suma 29,40 minutos de lookaheads y 5,59 de ramas completas. La suma reconstruida es aproximadamente 4,81 veces la de ramas de entropía para el mismo número de recuperaciones. **No es un benchmark end-to-end independiente:** excluye baseline, evaluación de tests, carga, algunas operaciones de scoring y reutilización/implementaciones alternativas; las ramas compartidas se contabilizan hipotéticamente en cada selector. No se deben sumar columnas entre selectores para calcular el tiempo real de la corrida. El experimento registra 16,51 minutos de generación de las 255 ramas únicas y 29,40 minutos de lookaheads.

El presupuesto igualado en número de ramas completas no iguala tokens, latencia ni costo total. Una comparación futura debe informar tanto recovery@k como recuperación bajo presupuesto de cómputo.

## 9. Experimentos anteriores: incertidumbre y fallo del programa

| Dataset | PASS | Tasa | IC 95% Wilson |
| --- | --- | --- | --- |
| HumanEval | 139/164 | 84.8% | 78.5%–89.5% |
| MBPP | 85/100 | 85.0% | 76.7%–90.7% |


Hay una observación por tarea y no hay duplicados de tarea/muestra/método ni valores faltantes en las ocho métricas analizadas. MBPP registra Qwen2.5-Coder-7B-Instruct; la pestaña HumanEval no registra el modelo en una columna, por lo que no se atribuye automáticamente el mismo. Los márgenes medios superan 1: no son directamente comparables con el margen probabilístico p1−p2 de branching; su escala es compatible con diferencias de logits, pero debe confirmarse con el código de esa corrida. Los registros no se mezclaron entre benchmarks.

Se eligieron ocho métricas interpretables por dataset: entropía media/máxima, margen medio/mínimo, tokens, tiempo, desviación de entropía y líneas de código. Se aplicó Mann–Whitney bilateral con corrección de empates y ajuste Benjamini–Hochberg a las 16 pruebas; las AUC tienen intervalos bootstrap marginales con 4.000 remuestreos. Es análisis exploratorio retrospectivo, no evaluación de un predictor entrenado.

| Dataset | Métrica | Media PASS | Media FAIL | AUC: valor alto → fallo | q (16 pruebas) |
| --- | --- | --- | --- | --- | --- |
| HumanEval | mean_entropy | 0.0806 | 0.0993 | 0.664 | 0.041 |
| HumanEval | max_entropy | 1.0534 | 1.1967 | 0.620 | 0.105 |
| HumanEval | mean_margin | 9.3357 | 8.6267 | 0.302 | 0.026 |
| HumanEval | min_margin | 0.5955 | 0.2961 | 0.336 | 0.041 |
| HumanEval | output_tokens | 63.3453 | 86.9600 | 0.598 | 0.173 |
| HumanEval | gen_time_s | 4.3112 | 5.9883 | 0.602 | 0.170 |
| HumanEval | entropy_std | 0.2102 | 0.2345 | 0.621 | 0.105 |
| HumanEval | code_lines | 7.1007 | 8.0400 | 0.531 | 0.624 |
| MBPP | mean_entropy | 0.1718 | 0.2013 | 0.580 | 0.371 |
| MBPP | max_entropy | 1.4791 | 1.7801 | 0.678 | 0.091 |
| MBPP | mean_margin | 7.8216 | 7.4063 | 0.440 | 0.494 |
| MBPP | min_margin | 0.2300 | 0.1002 | 0.291 | 0.041 |
| MBPP | output_tokens | 80.1294 | 108.7333 | 0.654 | 0.105 |
| MBPP | gen_time_s | 34.1488 | 46.3187 | 0.655 | 0.105 |
| MBPP | entropy_std | 0.3263 | 0.3541 | 0.585 | 0.371 |
| MBPP | code_lines | 7.8941 | 9.3333 | 0.583 | 0.371 |


En HumanEval hay asociación marginal de fallo con mayor entropía media, menor margen medio y menor margen mínimo tras este ajuste exploratorio. En MBPP solo el margen mínimo supera ese criterio. AUC menores que 0,5 en los márgenes significan que valores bajos, no altos, se asocian con fallos. Ninguna señal separa perfectamente éxitos de fallos.

![Asociaciones previas](/Users/matiask/Documents/programacion/LIS/ghost_prompt/analysis_20260910/03_asociaciones_previas.png)

### Sensibilidad a la longitud

Se ajustaron cuatro regresiones logísticas exploratorias separadas: fallo ~ métrica estandarizada + log(1+tokens), con intercepto. Son modelos asociativos con solo dos predictores; no se usan como clasificadores validados. La longitud se observa después de generar y puede ser parte del mecanismo: controlar por ella cambia la pregunta y no elimina confusión causal.

| Dataset | Métrica | OR por +1 DE | IC Wald 95% | p Holm (4) |
| --- | --- | --- | --- | --- |
| HumanEval | mean_entropy | 2.01 | [1.29, 3.13] | 0.0078 |
| HumanEval | min_margin | 0.46 | [0.22, 0.95] | 0.0684 |
| MBPP | mean_entropy | 3.40 | [1.45, 7.98] | 0.0151 |
| MBPP | min_margin | 0.26 | [0.07, 0.90] | 0.0684 |


La asociación condicional de entropía media con fallo aparece en ambos benchmarks, incluso donde el contraste marginal de MBPP era débil. Es un resultado sensible al modelo y al ajuste elegido, con 25 y 15 fallos respectivamente; no prueba causalidad ni generalización. Los márgenes mínimos no superan Holm en esta familia secundaria. Los errores guardados figuran como RuntimeError genérico en todos los fallos anteriores; no se interpretan como causa técnica específica sin descomponer el traceback.

## 10. Qué queda sin identificar y próximo experimento

1. Las 1.394 posiciones no evaluadas impiden estimar el oracle y validar completamente un selector nuevo. Por ejemplo, ordenar solo por Levenshtein requiere 44 ramas cuya etiqueta no existe; con las conocidas recuperaría al menos 9 problemas, y el máximo compatible con las faltantes es 19. Ese rango no constituye un resultado de rendimiento.

2. Los tests son HumanEval base. No hay resultado de HumanEval+ que verifique estas recuperaciones. Superar tests no garantiza corrección para todas las entradas.

3. HumanEval/26 sirvió para diseñar el selector; sus tres recuperaciones en 49 posiciones son desarrollo, no réplicas independientes que aumenten n. Tampoco se deben añadir experimentos RAG de otro modelo o protocolo a esta cohorte.

4. El estudio usa un único modelo y una semilla del control aleatorio. Repetir semillas sobre las mismas tareas estima variabilidad del control, pero no aumenta el número de problemas independientes.

5. Una métrica alineada debe distinguir inserciones/desplazamientos de cambios de operadores, literales y flujo. Conviene conservar indentación, usar elementos léxicos de Python y registrar distancia de edición junto con las componentes actuales. La validación semántica exige más que similitud textual.

Congelar antes de la próxima evaluación: métrica alineada, regla híbrida si se va a probar, k principal, presupuesto computacional, tratamiento de EOS/truncamiento, prueba primaria y familia de comparaciones. Evaluar los cuatro métodos sobre exactamente las mismas tareas nuevas y reportar análisis pareado. Registrar IDs y probabilidades del par ordenado en la misma pasada.

### Planificación del tamaño muestral

Simulación prospectiva ilustrativa de McNemar exacta bilateral, α=0,05, 30.000 simulaciones por escenario, suponiendo problemas independientes. Se especifica una diferencia real δ y fracción discordante q: probabilidades (A solo, B solo, resto) = ((q+δ)/2, (q−δ)/2, 1−q). No es potencia post-hoc que confirme el resultado actual. Los escenarios son supuestos, no efectos estimados con certeza.

| δ | Discordancia q | n fallos elegibles | Potencia simulada |
| --- | --- | --- | --- |
| 20 pp | 30.0% | 20 | 19.6% |
| 20 pp | 30.0% | 60 | 79.7% |
| 20 pp | 30.0% | 80 | 90.9% |
| 20 pp | 30.0% | 100 | 96.3% |
| 10 pp | 30.0% | 100 | 37.1% |
| 10 pp | 30.0% | 200 | 70.1% |
| 10 pp | 30.0% | 300 | 87.2% |
| 20 pp | 50.0% | 100 | 79.0% |
| 20 pp | 50.0% | 150 | 93.2% |


Con δ=20 pp y q=30%, 80–100 fallos elegibles tienen buena potencia en estos supuestos. Una diferencia de 10 pp necesita bastantes más; con n=300 la potencia simulada ronda 87%. No son cantidades totales de tareas ni una promesa de reclutamiento posible en HumanEval: harán falta otros problemas o benchmarks y redefinir cuidadosamente la población. Más comparaciones y dependencia entre tareas aumentan las necesidades.

## 11. Conclusión comunicable

> En una validación exploratoria sobre 20 problemas donde el modelo fallaba, intervenir sobre una sola decisión de token permitió recuperar diez problemas con cinco alternativas seleccionadas. Entropía, margen y nuestro selector basado en divergencia alcanzaron la misma cobertura; el control aleatorio recuperó seis. La evidencia todavía no establece superioridad del selector semántico. Identificamos además sensibilidad al desfase y un costo de lookahead que deben corregirse y evaluarse en datos nuevos.

**Estado: compartir con salvedades.** Las cuentas principales y su trazabilidad fueron verificadas. Afirmar superioridad semántica, generalización a otros modelos o equivalencia de programas requeriría revisar la conclusión. La guía de validación determinó el análisis por problema, el tratamiento explícito de resultados faltantes y las comprobaciones independientes; la selección de figuras preserva incertidumbre, denominadores y diferencias de costo.

## Reproducción y archivos

Ejecutar, en este orden, `profile.py`, `analyze.py`, `supplement.py`, `extra_checks.py`, `make_figures.py` y `write_report.py`. Semilla principal 20260910. `analyze.py` usa 30.000 remuestreos por intervalo de problema, 4.000 por AUC anterior y 50.000 permutaciones globales de contraste; `supplement.py` reemplaza la inferencia global principal por enumeración exacta. Dependencias: Python, pandas, NumPy, SciPy y matplotlib. Los scripts aceptan paquetes instalados normalmente y añaden `/private/tmp/ghost_stats_deps` como ubicación opcional de esta sesión.

Los snapshots de Drive y sus hashes se conservan en el directorio. Las fuentes Google permanecieron sin modificaciones. Las tablas derivadas en CSV, resultados en JSON y gráficos PNG/SVG acompañan este informe. El paquete ZIP incluye las fuentes originales locales necesarias bajo `sheet_build_data/` y esta carpeta bajo `analysis_20260910/`; los scripts funcionan desde esa estructura.

Referencias de implementación estadística: [McNemar exacta, statsmodels](https://www.statsmodels.org/dev/generated/statsmodels.stats.contingency_tables.mcnemar.html) y [Mann–Whitney, SciPy](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html). La primera sustenta el contraste pareado binomial condicional; la segunda, el contraste entre las muestras PASS y FAIL de los experimentos previos. No se usaron datos de la web para estimar resultados.